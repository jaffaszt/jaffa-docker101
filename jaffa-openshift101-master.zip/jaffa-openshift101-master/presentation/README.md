# Introduction to Openshift by Jaffa Sztejnbok 

[Presentation](openshift%20101%20ppt.pdf)
